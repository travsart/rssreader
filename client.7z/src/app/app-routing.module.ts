import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';

import {HomeComponent} from './home/home.component';
import {LogTableComponent} from './log-table/log-table.component';
import {LogFormComponent} from './log-form/log-form.component';

const routes: Routes = [
  {
    path: 'logform',
    component: LogFormComponent
  },
  {
    path: 'logtable',
    component: LogTableComponent
  },
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: '',
    component: HomeComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: []
})
export class AppRoutingModule {
}
