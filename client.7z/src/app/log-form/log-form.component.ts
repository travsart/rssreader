import {Component} from '@angular/core';
import {Validators, FormGroup, FormBuilder, FormControl} from '@angular/forms'
import {ActivatedRoute, Router} from '@angular/router';
import * as moment from 'moment';

@Component({
  selector: 'app-log-form',
  templateUrl: './log-form.component.html',
  styleUrls: ['./log-form.component.css']
})
export class LogFormComponent {
  inputForm: FormGroup;
  times = [
    moment().subtract(1, 'w').startOf('day').toDate(),
    moment().toDate()
  ];


  constructor(private formBuilder: FormBuilder, private route: ActivatedRoute, private router: Router) {
    this.inputForm = this.formBuilder.group({
      startTime: [Validators.required],
      endTime: [Validators.required],
      fieldType: [Validators.required],
      fieldValue: [Validators.required]
    }, {validator: this.timesError.bind(this)});

    this.inputForm.setValue({
      startTime: null,
      endTime: null,
      fieldType: 'project',
      fieldValue: ''
    });

  }

  public timesError(group: FormGroup) {

    const st = moment(this.times[0]);
    const et = moment(this.times[1]);

    if (!st.isValid() || !et.isValid()) {
      console.log('sad');
      group.setErrors({notValid: true});
      return false;
    } else {
      return true;
    }
  }

  public onSubmit() {
    if (this.timesError(this.inputForm)) {
      this.inputForm.patchValue({startTime: this.times[0].toISOString(), endTime: this.times[1].toISOString()});
      this.router.navigate(['/logtable'], {queryParams: this.inputForm.value});
    }
  }
}
