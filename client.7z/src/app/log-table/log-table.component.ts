import {AfterViewInit, Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {MatPaginator, MatSort} from '@angular/material';
import {debounceTime, distinctUntilChanged, tap} from 'rxjs/operators';
import 'rxjs/add/observable/of';
import {animate, state, style, transition, trigger} from '@angular/animations';
import {merge} from 'rxjs/observable/merge';
import {fromEvent} from 'rxjs/observable/fromEvent';

import {LogDataSource} from '../services/log.datasource';
import {LogService} from '../services/log.service';

@Component({
  selector: 'app-log-table',
  templateUrl: './log-table.component.html',
  styleUrls: ['./log-table.component.css'],
  animations: [
    trigger('outputExpand', [
      state('void', style({height: '0px', minHeight: '0', visibility: 'hidden'})),
      state('*', style({height: '*', visibility: 'visible'})),
      transition('void <=> *', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ])
  ]
})

export class LogTableComponent implements OnInit, AfterViewInit {
  expandedOutput: any;
  dataSource: LogDataSource;
  form: {
    startTime: string,
    endTime: string,
    fieldType: string,
    fieldValue: string
  };
  displayedColumns = ['id', 'project', 'user', 'datetime'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('input') input: ElementRef;

  isExpansionDetailRow = (i, row) => row.hasOwnProperty('output');

  constructor(private route: ActivatedRoute,
              private logService: LogService) {

  }

  ngOnInit() {

    this.form = this.route.snapshot.queryParams.valueOf();
    this.dataSource = new LogDataSource(this.logService);

    this.dataSource.loadLogs(this.form.startTime, this.form.endTime, this.form.fieldType, this.form.fieldValue, '', 'DESC',
      'datetime', 0, 10);
  }

  ngAfterViewInit() {

    this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

    fromEvent(this.input.nativeElement, 'keyup')
      .pipe(
        debounceTime(150),
        distinctUntilChanged(),
        tap(() => {
          this.paginator.pageIndex = 0;

          this.loadLogPage();
        })
      )
      .subscribe();
    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
        tap(() => this.loadLogPage())
      )
      .subscribe();

  }

  loadLogPage() {
    this.dataSource.loadLogs(
      this.form.startTime,
      this.form.endTime,
      this.form.fieldType,
      this.form.fieldValue,
      this.input.nativeElement.value,
      this.sort.direction,
      'datetime',
      this.paginator.pageIndex,
      this.paginator.pageSize
    );
  }
}
