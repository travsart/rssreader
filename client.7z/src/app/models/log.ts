export interface LogModel {
  id: string;
  project: string;
  user: string;
  output: Array<Object>;
  datetime: Date;
  count: number;
}
