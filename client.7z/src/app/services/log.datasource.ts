import {CollectionViewer, DataSource} from '@angular/cdk/collections';
import {Observable} from 'rxjs/Observable';
import {LogModel} from '../models/log';
import {LogService} from './log.service';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {catchError, finalize} from 'rxjs/operators';
import {of} from 'rxjs/observable/of';

export class LogDataSource implements DataSource<LogModel> {

  private logsSubject = new BehaviorSubject<LogModel[]>([]);

  private loadingSubject = new BehaviorSubject<boolean>(false);

  public loading$ = this.loadingSubject.asObservable();

  constructor(private logService: LogService) {

  }

  loadLogs(startTime: string,
           endTime: string,
           fieldType: string,
           fieldValue: string,
           filter: string,
           sortDirection: string,
           sortField: string,
           pageIndex: number,
           pageSize: number) {

    this.loadingSubject.next(true);

    this.logService.findAllLogsByField(startTime, endTime, fieldType, fieldValue, filter, sortDirection, sortField,
      pageIndex, pageSize).pipe(
      catchError(() => of([])),
      finalize(() => this.loadingSubject.next(false))
    )
      .subscribe(logs => this.logsSubject.next(logs));

  }

  connect(collectionViewer: CollectionViewer): Observable<LogModel[]> {
    console.log('Connecting to data source');
    return this.logsSubject.asObservable();
  }

  disconnect(collectionViewer: CollectionViewer): void {
    this.logsSubject.complete();
    this.loadingSubject.complete();
  }
}
