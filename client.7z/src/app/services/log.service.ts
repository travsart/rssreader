import {Injectable} from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Observable} from 'rxjs/Observable';
import {LogModel} from '../models/log';
import {map} from 'rxjs/operators';


@Injectable()
export class LogService {

  url = 'http://192.168.0.212:1337';

  constructor(private http: HttpClient) {

  }

  findLogById(logId: string): Observable<LogModel> {
    return this.http.get<LogModel>(`/api/log/${logId}`);
  }

  findAllLogs(): Observable<LogModel[]> {
    return this.http.get(this.url + '/log')
      .pipe(
        map(res => res['payload'])
      );
  }

  findAllLogsByField(startTime: string, endTime: string, fieldType: string, fieldValue: string, filter = '', sortDirection = 'DESC',
                     sortField = 'datetime', pageNumber = 0, pageSize = 3): Observable<LogModel[]> {
    return this.http.get(this.url + '/logbyfield', {
      params: new HttpParams()
        .set('startTime', startTime)
        .set('endTime', endTime)
        .set('fieldType', fieldType)
        .set('fieldValue', fieldValue)
        .set('filter', filter.trim())
        .set('sortField', sortField)
        .set('sortDirection', sortDirection)
        .set('pageNumber', pageNumber.toString())
        .set('pageSize', pageSize.toString())
    }).pipe(
      map(res => res)
    );
  }


}
